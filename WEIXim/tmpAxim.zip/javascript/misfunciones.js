/**
*	En este fichero javascript se deben colocar aquellas funciones javascript
*	dise�adas por el propio usuario y que en el modelo UML se indic� como
*  	una asociaci�n UML cuyo m�todo a ejecutar es "CUSTOM:xxxx", donde xxxx
*	es el nombre de una de las funciones que se buscar�n en este fichero.
**/

function habilita(transform,textoEntrada){
	if ($(textoEntrada).value==null || $(textoEntrada).value==""){
		$(transform).disabled=true;
	}else{
		$(transform).disabled=false;
	}

}

function habilitaButton(transform,textoEntrada){
	// la funci�n $(....) est� definida en codigojavascript.js. Equivale
	// a hacer "document.getElementById(...)".
	if ($(textoEntrada).value==null || $(textoEntrada).value==""){
		alert("El �rea \""+textoEntrada+ "\" no debe estar vac�a");
	}else{
		$(transform).disabled=false;
	}

}

function dimeValor(elemento){
	var elem=document.getElementById(elemento);
	alert("El valor del elemento \""+elemento+"\" es "+elem.value);
}