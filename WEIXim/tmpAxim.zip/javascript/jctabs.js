function setTab(tab, link, numTabs, prefijoTab) {
				for (var i = 1; i <= numTabs; i++) {
					document.getElementById(prefijoTab+i).style.display = "none";	
					document.getElementById('tabDatos'+i).className = "";		
				}
				document.getElementById(tab).style.display = "block";
				document.getElementById(link).className = "tab-button";

}
			
function setTab2(tab, link, numTabs, idcontenedor, prefijo) {
	var contenedor=document.getElementById(idcontenedor);
	for (var i = 0; i < contenedor.childNodes.length; i++) {
	
		var hijo=contenedor.childNodes[i];
		//if (hijo.nodeType==Node.ELEMENT_NODE){ // como IE 6 no tiene lo de Node,  lo ponemos a pelo, es decir, la comparacion de abajo:
			if (hijo.nodeType==1){ 
			//alert(hijo.nodeType);
			hijo.style.display= "none";
			//alert(prefijo+i);
			//document.getElementById(prefijo+i).className = "";	
		}
		
	}
	
	for (var j = 1; j<= numTabs; j++) {
		document.getElementById(prefijo+j).className = "tab-button";
	}
	document.getElementById(tab).style.display = "block";
	document.getElementById(link).className = "tab-buttonSelected";

}