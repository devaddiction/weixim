//*****************************************************************************
//Funciones diversas
//*****************************************************************************

var windowEspera=null; //referenciara a la window que indica "espere" cuando una operacion de WS se esta ejecutando

function notisclickable() {
	alert('Imposible hacer click en el elemento, defini� isClickable a false');
}


function transitar(paginaDestino) {
	ocultaCapasCpC();
	muestraCapa("cpc"+paginaDestino);
}


//funcion que comprueba si un elemento es un checkbox, devolviendo true o false. Como parametro se pasa el id del elemento a comprobar
function compruebaCheckBox(idElem) {
	var elem= document.getElementById(idElem);
	if (elem!=null){
	//alert(elem.type);
		if (elem.type=="checkbox") {
			//alert('Es un checkbox');
			return true;
		}else{
			return false;
		}
	}else{
		//alert('elem null');
		return false;
	}
	
}

//funcion que comprueba si un elemento es un radio, devolviendo true o false. Como parametro se pasa el id del elemento a comprobar
function compruebaRadioButton(idElem) {
	var elem= document.getElementById(idElem);
	if (elem!=null){
		//alert('para id='+idElem+',tipo='+elem.type);
		if (elem.type=="radio") {
			//alert('Es un radiobutton');
			return true;
		}else{
			return false;
		}
	}else{
		//alert('elem null para id='+idElem);
		return false;
	}
	
}

//funcion que comprueba si un radiobutton esta marcado o no-.
function compruebaMarcadoRadioButton(idElem) {
	var elem= document.getElementById(idElem);
	if (elem.checked){
		//alert(' radioButton marcado!');
		return true;
	}else{
		return false;
	}
	
}


//funcion que comprueba si un checkbox esta marcado o no-.
function compruebaMarcadoCheckBox(idElem) {
	var elem= document.getElementById(idElem);
	if (elem.checked){
		//alert(' checkbox marcado!');
		return true;
	}else{
		return false;
	}
	
}



function ejecutaWSbyIBM(paginaDestino,wsdl, metodo){
	if (window.XMLHttpRequest && usandoFirefox3()) {// Si es Firefox
			netscape.security.PrivilegeManager.enablePrivilege("UniversalBrowserRead");
	}

	  var call = new WS.Call(wsdl); 
	  //var nsuri = 'http://localhost:8080';
	  var nsuri='http://ws.apache.org/axis2';
	  var qn_op = new WS.QName(metodo,nsuri);
	  var qn_op_resp = new WS.QName(metodo+'Response',nsuri);  
	  
	  //Recogemos los valores de los parametros (del 4� en adelante de los que nos lleguen. 3 son seguros, el resto es variable)
		 var paramValues = new Array();
		// alert('tam arguments='+arguments.length);
		 for(var i=3;i<arguments.length-1;i++) {
			//si el parametro tiene como nombre p.e. "TPDB", es que estamos pasando una cte
			//var patron=/^cte_*/;
			 var patron=/^\"*\"/;
			 var patron2=/^cte_*/;
			if (arguments[i].match(patron)){ //si un argumento esta entre "", se las quito y es una cte.
				//alert("encaja!="+arguments[i]);
				paramValues[i-3]=arguments[i].substring(1,arguments[i].length-1);
				//alert(paramValues[i-3]);
			}else if (arguments[i].match(patron2)){ //si un argumento esta entre "cte_", se lo quito y es una cte
				//alert("encaja!="+arguments[i]);
				paramValues[i-3]=arguments[i].substring(4);
				//alert(paramValues[i-3]);	
			//sino, hay que recoger el value del elemento html con nombre "arguments[i]"
			}else{
				if (document.getElementById(arguments[i])!=null){
					paramValues[i-3]=document.getElementById(arguments[i]).value;	
				}else{
					alert("No existe un elemento HTML cuyo id sea \""+arguments[i]+"\"");
					return false;
				}
			}
			
			//si los elementos son checkbox simples(no grupo), debemos transformar sus valores 'on' u 'off' a 'true' o 'false'
			if (compruebaCheckBox(arguments[i])==true){			
				var grupocheck=document.getElementsByName(arguments[i]);
				var valor="";
				if (grupocheck.length==1) {//solo hay un checkbox con ese nombre
					if (compruebaMarcadoCheckBox(arguments[i])==true){
						paramValues[i-3]='true';
					}else{
						paramValues[i-3]='false';
					}
				}else{ //se trata de un grupo de checkbox. Tenemos que quedarnos con el valor del checkbox marcado.
						for(var k=0;k<grupocheck.length;k++){
							if (grupocheck[k].checked){
								valor=grupocheck[k].value;
							}
						}
						paramValues[i-3]=valor;
				}
			}
			
			//si los elementos son radiobuttons..
			if (compruebaRadioButton(arguments[i])==true){			
				var gruporadio=document.getElementsByName(arguments[i]);
				//alert("tam grupo radio="+gruporadio.length);
				var valor="";
				if (gruporadio.length==1) {//solo hay un radiobutton con ese nombre
					if (compruebaMarcadoRadioButton(arguments[i])==true){
						paramValues[i-3]='true';
					}else{
						paramValues[i-3]='false';
					}
				}else{ //se trata de un grupo de radiobuttons. Tenemos que quedarnos con el valor del radiobutton marcado.
						for(var k=0;k<gruporadio.length;k++){
							if (gruporadio[k].checked){
								valor=gruporadio[k].value;
								//alert("valor radio="+valor);
							}
						}
						paramValues[i-3]=valor;
				}
			}
			
		 }
			
	  //Recogemos los nombres de los par�metros
		var paramNames = new Array();
		for (j=0; j< paramValues.length;j++){
			paramNames[j]= "param"+j;
		}	
		
		//Recogemos el id del elemento html en el que se va a cargar el resultado de la ejecuci�n del WS
			var idElementoDestino=arguments[arguments.length-1];
	  
	  //Array de parametros en notacion JSON. Los parametros son objetos con propiedades clave y valor
	  var params=new Array();
	  for (k=0; k< paramNames.length;k++){
			params[k]={name:paramNames[k], value:paramValues[k]};
				//alert('param='+paramNames[k]+',valor='+paramValues[k]);
		}	
	  
	  
	  //windowEspera=window.open('./EsperaInterna.html','waitamoment','width=400,height=300');
	  //windowEspera.focus();
	  document.getElementById("tituloPaginaInterna").style.display="none";
	  document.getElementById("tiempoEsperaInterna").style.display = "block";
	  //Invocacion del WS
	  call.invoke_rpc(
					qn_op,
					params,
					SOAP.NOENCODING, //Un parametro de configuracion creo
					function(call,envelope) { // Funcion de respuesta cuando se obtiene el resultado de la invocacion del WS
						try{
							 // alert(arguments[2].escapeHTML());
							  var exito=true;
							  
							  if (envelope==null || envelope.get_body()==null) { //axis parado
								exito=false;
							  }
							  //res contiene el resultado
							  var res = envelope.get_body().get_all_children()[0].get_all_children()[0].get_value();
							  
						}catch(e){
								// exito=false;
								if (res==null) {
									res="";
								}
						}finally{
							 //alert('Resultado='+res);
							  document.getElementById("tiempoEsperaInterna").style.display = "none";
							  document.getElementById("tituloPaginaInterna").style.display="block";
							
							  if (exito==true){
								alert("Invocaci�n realizada con �xito");
							  }else{
								alert("Se produjo un error al invocar el SW");
							  }
							  if (paginaDestino=='this'){ //la pagina destino es la misma pagina
								vuelvaResultadoEnMismaPagina(idElementoDestino,res);	
							  }else{
								vuelcaResultado(paginaDestino,idElementoDestino,res);
							  }
						}		
					}
	  );
}



//Esta funcion vuelva el valor que se le pasa como parametro al elemento HTML de la pagina actual
function vuelvaResultadoEnMismaPagina(elemDestino,valor){
	$(elemDestino).value=valor;
	$(elemDestino).focus();
}


//Esta funcion vuelca el valor que se le pasa como parametro al elemento HTML que est� en paginaDestino. 
//Para ello mostrar� la capa correspondiente con id= cpcPaginaDestino
function vuelcaResultado(paginaDestino, elemDestino,valor){
	ocultaCapasCpC();
	muestraCapa("cpc"+paginaDestino);
	$(elemDestino).value=valor;
	$(elemDestino).focus();			
}


/**Ejecutara algo como:
*decideWS('this','comboOp','suma|http://localhost:8080/axis2/services/Calculator|campoA|campoB|salida','resta|http://localhost:8080/axis2/services/Calculator|campoA|campoB|salida')"
*del arg 2 en adelante seran los distintos metodos que pueden ejecutarse en funcion del valor del elemento HTML cuyo id es idElemJuez.
*Si por ejemplo dicho elemento es un combo y en el momento de ejecutar decideWS tiene el valor "suma", se ejecutar� el metodo suma. Los elementos necesarios
*para dicha ejecucion se pasan como argumento a decideWS. Ej: suma|http://localhost:8080/axis2/services/Calculator|campoA|campoB|salida
*/
function decideWS(paginaDestino, idElemJuez){
	var arrayMetodos = new Array(); //almacenara chorizos del estilo "suma|http://localhots...|campoA|campoB|salida"
	var arrayNombreMetodos=new Array(); //almacenara el primer token de la cadena anterior, es decir, la operacion en s� (suma, resta,etc...)
	var eleccion=""; //almacenara el nombre de la operacion a ejecutar
	
	for(var i=2;i<arguments.length;i++) {
			arrayMetodos[i-2]=arguments[i];
			var arrayAux=arrayMetodos[i-2].split("|");
			var nombreMetodo=arrayAux[0];
			arrayNombreMetodos[i-2]=nombreMetodo;
			//alert("option value="+nombreMetodo);
	}		
	
	var juez=document.getElementById(idElemJuez);
	//alert ("TITULO="+document.title);
	if (juez==null) {
		alert("No se pudo obtener el elemento HTML con id="+idElemJuez);
	}else{
		 //si el juez es un grupo de radiobuttons(radiobuttons con el mismo nombre), tenemos que averiguar cual de ellos esta
		 //marcado y quedarnos con su valor.
		 if (juez.type=="radio"){
			var radiogroup=document.getElementsByName(idElemJuez);
			for(var i=0;i<radiogroup.length;i++){
				if (radiogroup[i].checked){
					eleccion=radiogroup[i].value;
					//alert("eleccion rb="+eleccion);
				}
				
			}
		 //si el juez es un grupo de checkbuttons(checkbuttons con el mismo nombre), nos vamos a quedar con el valor de uno de los que esten marcados.
		 //Asi que mejor que el usuario se asegure de tener marcado solo uno si quiere que vaya bien la cosa
		}else if (juez.type=="checkbox"){
				var checkboxgroup=document.getElementsByName(idElemJuez);
				for(var i=0;i<checkboxgroup.length;i++){
					if (checkboxgroup[i].checked){
						eleccion=checkboxgroup[i].value;
					}
				}
				
		//el juez sera lo mas normal entonces un combo, aunque tambien podria ser cualquier otro elemento HTML que tenga un value(como un input type="text" p.e.)		
		}else{ 
			eleccion=juez.value;
		}
		
		//comprobamos si la operacion elegida a ejecutar es estatica(CASO 1) o se a�adi� dinamicamente(CASO 2)
		var caso1=false;
		for (var i=0;i<arrayNombreMetodos.length;i++){
			if (eleccion==arrayNombreMetodos[i]){
				caso1=true;
			}
		}
		
		//CASO 1: si se ha elegido una operacion de las que ya venian de serie...(las estaticas)
		if (caso1==true){
			var arrayElementosEjecutar=new Array(); //almacenara p.e. { suma, http://localhost:8080/axis2/services/Calculator,campoA, campoB, salida}
			for (var i=0;i<arrayMetodos.length;i++){
				if (eleccion==(arrayMetodos[i].split("|"))[0]){
					arrayElementosEjecutar=arrayMetodos[i].split("|");
					//alert("@@@="+arrayElementosEjecutar);
					ejecutaWS_Decide(paginaDestino, arrayElementosEjecutar);
					break;
				}
			}
		//CASO 2: si se ha elegido una operacion que previamente se ha a�adido dinamicamente...
		}else{
			var arrayElementosEjecutar=eleccion.split("|"); //almacenara p.e. { suma, http://localhost:8080/axis2/services/Calculator,campoA, campoB, salida}
			//alert("@@@="+arrayElementosEjecutar);
			ejecutaWS_Decide(paginaDestino,arrayElementosEjecutar);
		}
	}
	
}

function ejecutaWS_Decide(paginaDestino, arrayElementosEjecutar){
    var wsdl=arrayElementosEjecutar[1];
	if (arrayElementosEjecutar.length==3){ //minimo tendra la operacion, la wsdl y el campo donde volcar la salida
		ejecutaWSbyIBM(paginaDestino,wsdl,  arrayElementosEjecutar[0],arrayElementosEjecutar[2]);
	}else if (arrayElementosEjecutar.length==4){ 
		ejecutaWSbyIBM(paginaDestino,wsdl, arrayElementosEjecutar[0],arrayElementosEjecutar[2],arrayElementosEjecutar[3]);
	}else if (arrayElementosEjecutar.length==5){ 
		ejecutaWSbyIBM(paginaDestino,wsdl, arrayElementosEjecutar[0],arrayElementosEjecutar[2],arrayElementosEjecutar[3],arrayElementosEjecutar[4]);
	}else if (arrayElementosEjecutar.length==6){ 
		ejecutaWSbyIBM(paginaDestino,wsdl, arrayElementosEjecutar[0],arrayElementosEjecutar[2],arrayElementosEjecutar[3],arrayElementosEjecutar[4],arrayElementosEjecutar[5]);
	}else if (arrayElementosEjecutar.length==7){ 
		ejecutaWSbyIBM(paginaDestino,wsdl, arrayElementosEjecutar[0],arrayElementosEjecutar[2],arrayElementosEjecutar[3],arrayElementosEjecutar[4],arrayElementosEjecutar[5],
									arrayElementosEjecutar[6]);
	}else if (arrayElementosEjecutar.length==8){ 
		ejecutaWSbyIBM(paginaDestino,wsdl, arrayElementosEjecutar[0],arrayElementosEjecutar[2],arrayElementosEjecutar[3],arrayElementosEjecutar[4],arrayElementosEjecutar[5],
									arrayElementosEjecutar[6],arrayElementosEjecutar[7]);
	}else if (arrayElementosEjecutar.length==9){ 
		ejecutaWSbyIBM(paginaDestino,wsdl,arrayElementosEjecutar[0],arrayElementosEjecutar[2],arrayElementosEjecutar[3],arrayElementosEjecutar[4],arrayElementosEjecutar[5],
									arrayElementosEjecutar[6],arrayElementosEjecutar[7],arrayElementosEjecutar[8]);
	}else if (arrayElementosEjecutar.length==10){ 
		ejecutaWSbyIBM(paginaDestino,wsdl, arrayElementosEjecutar[0],arrayElementosEjecutar[2],arrayElementosEjecutar[3],arrayElementosEjecutar[4],arrayElementosEjecutar[5],
									arrayElementosEjecutar[6],arrayElementosEjecutar[7],arrayElementosEjecutar[8],arrayElementosEjecutar[9]);
	}else if (arrayElementosEjecutar.length==11){ 
		ejecutaWSbyIBM(paginaDestino,wsdl, arrayElementosEjecutar[0],arrayElementosEjecutar[2],arrayElementosEjecutar[3],arrayElementosEjecutar[4],arrayElementosEjecutar[5],
									arrayElementosEjecutar[6],arrayElementosEjecutar[7],arrayElementosEjecutar[8],arrayElementosEjecutar[9],arrayElementosEjecutar[10]);
	}
}

/**
* Esta funcion recoge la url del fichero indicado en el input type="file" con id= idBuscador, y vuelva el contenido de dicho fichero en el elemento HTML de id
* "elemDestino" que se encuentra en la pagina "paginaDestino".
*/
function cargaFichero(idBuscador, paginaDestino, elemDestino){
	var xhtpr = false
	if (window.XMLHttpRequest && !navigator.appName.match("Internet Explorer")) {// Si es Mozilla, Safari etc
		//netscape.security.PrivilegeManager.enablePrivilege("UniversalBrowserRead");
		xhtpr = new XMLHttpRequest();
	} else if (window.ActiveXObject){ // pero si es IE
		try {
		xhtpr = new ActiveXObject("Msxml2.XMLHTTP")
		} catch (e){ // en caso que sea una versi�n antigua
			try{
				xhtpr = new ActiveXObject("Microsoft.XMLHTTP")
			}
			catch (e){
			}
		}
	}else{
		return false;
	}
	
	xhtpr.onreadystatechange=function(){ // funci�n de respuesta
		cargarFicheroResultado(xhtpr,paginaDestino, elemDestino);
	}
	
	var url=document.getElementById(idBuscador).value;
	//alert("url fichero="+url);
	if (url==null) {
		alert("url del fichero nula");
	}else{
		if (usandoFirefox3()) { //si es firefox 3, usamos una cosa especial para el
			netscape.security.PrivilegeManager.enablePrivilege("UniversalFileRead");
			var busc=document.getElementById(idBuscador);
			res=busc.files.item(0).getAsText("");
			if (paginaDestino=='this'){ //la pagina destino es la misma pagina
				vuelvaResultadoEnMismaPagina(elemDestino,res);	
			}else{
				vuelcaResultado(paginaDestino,elemDestino,res);
			}
		}else{
			xhtpr.open('GET', url, true); // asignamos los m�todos open y send
			xhtpr.send(null);
		//alert("send ok");
		}	
	}
}
// todo es correcto y ha llegado el momento de poner la informaci�n requerida
// en su sitio en la pagina xhtml
function cargarFicheroResultado(xhtpr, paginaDestino,idElemDestino){
	if (xhtpr.readyState == 4 && (xhtpr.status==200 || window.location.href.indexOf("http")==-1)){
		var res=xhtpr.responseText;
		if (paginaDestino=='this'){ //la pagina destino es la misma pagina
				vuelvaResultadoEnMismaPagina(idElemDestino,res);	
		}else{
				vuelcaResultado(paginaDestino,idElemDestino,res);
		}
		
	}
}



/**
* Funcion que procesa a una cadena para el tema de las constantes.
* Si la cadena esta entrecomillada o la cadena es de la forma cte_xxx,
* se le quitan las "" o el prefijo cte_ respectivamente.
**/
function limpiaArgumentoCte(cad){
	var res="";
	var patron=/^\"*\"/;
	var patron2=/^cte_*/;
	
	if (cad.match(patron)){ //si un argumento esta entre "", se las quito y es una cte.
		//alert("encaja!="+cad);
		res=cad.substring(1,cad.length-1);
		//alert(res);
	}else if (cad.match(patron2)){ //si un argumento esta entre "cte_", se lo quito y es una cte
		//alert("encaja!="+cad);
		res=cad.substring(4);
	}else{
		res=cad;
	}	
				
	return res;		
}

function esArgumentoCte(cad){
	var patron=/^\"*\"/;
	var patron2=/^cte_*/;
	
	if (cad.match(patron)){ //si un argumento esta entre "", se las quito y es una cte.
		return true;
	}else if (cad.match(patron2)){ //si un argumento esta entre "cte_", se lo quito y es una cte
		return true;
	}else{
		return false;
	}	
				
}

function recogeValorCteOArgumento(cad){
	var res="";
	if (esArgumentoCte(cad)){
		res=limpiaArgumentoCte(cad);
		//alert("limpia="+res);
	}else{
		res=document.getElementById(cad).value; 
	}
	
	return res;
}

/**
* Funcion que a�ade una operacion de WS a un elemento HTML como un combo o un grupo de radioButtons, cuyo id
*es idElemDestino. Por ejemplo, si el elemento al que se a�ade una operacion es un combo, se le a�ade una nueva
* opcion a este, cuyo nombre es el nombre de la operacion(ej: suma) y cuyo value es p.e:   {suma|http://localhost......|campoA|campoB|salida}
* El argumento idparametros contiene un id de un elemento html en cuyo valor se encuentran enumerados entre comas los parametros
* de ejecucion de la nueva operacion a a�adir .Ej: "campoA, campoB, salida"
* elemDestino se encontrar� en paginaDestino.
* labelOperacion: por ejemplo si a�adir una operacion significa a�adir un radiobutton, labelOperacion sera el nombre de la etiqueta que acompa�e
* a dicho radioButton. Tambien sera el id de dicho radioButton. Para los combo no tiene sentido.
* direccion contendra "horizontal" o "vertical". Este campo indica la direccion hacia donde crecer si por ejemplo hay que a�adir un radiobutton nuevo
* para indicar la nueva operacion. Para el caso de un combo no tiene sentido.
* EJ: addOperationWS('this','newwsdl','radio1','newlabelop','newoperacion','newargumentos','cte_horizontal')
*/
function addOperationWS(paginaDestino,idwsdl,idElemDestino,idlabelOperacion,idoperacion, idparametros,iddireccion){
	var elemDestino=null; //el elemento que indicar� las distintas operaciones a ejecutar.
	//var disparador=null; //el elemento que tendra un evento del tipo decideWS
	var otraPagina=false;
	var wsdl=recogeValorCteOArgumento(idwsdl);
	if (wsdl=="") {
		alert("No se especific� la URL del SW "); return false;
	}
	var labelOp=recogeValorCteOArgumento(idlabelOperacion);
	if (labelOp=="") {
		alert("No se especific� un nombre para identificar al m�todo del SW"); return false;
	}
	var operacion=recogeValorCteOArgumento(idoperacion);
	if (operacion=="") {
		alert("No se especific� el nombre del m�todo del SW" ); return false;
	}
	var parametros=recogeValorCteOArgumento(idparametros);
	if (parametros=="") {
		alert("No se especificaron argumentos para el m�todo del SW "+operacion.value); return false;
	}
	var direccion=recogeValorCteOArgumento(iddireccion);
	if (direccion=="") {
		alert("No se especific� la direcci�n (horizontal o vertical"); return false;
	}
	
	//recogemos el resto de parametros de la llamada a addOperationWS
	var arrayParams=parametros.split(","); //contendra p.e. {campoA,campoB, salida}. Lo troceamos
	for(var i=0;i<arrayParams.length;i++){
			arrayParams[i]=trim(arrayParams[i]);
	}
	//alert("arrayParams="+arrayParams);
	
	//Obtenemos el elemento elemDestino, que se encuentran en paginaDestino.
	if (paginaDestino=='this'){
		elemDestino=document.getElementById(idElemDestino);
		//disparador=document.getElementById(idElemDisparador);
	}else{
		ocultaCapasCpC();
		muestraCapa("cpc"+paginaDestino);
		elemDestino=document.getElementById(idElemDestino);
		//disparador=document.getElementById(idElemDisparador);
	}	
	
	var stringParams=""; //almacenara algo como {campoA,campoB,salida}
	stringParams=arrayParams[0];
	for (var i=1; i<arrayParams.length;i++){
		stringParams=stringParams+"|"+arrayParams[i];
	}
	var cad=operacion+"|"+wsdl+"|"+stringParams; //almacenara algo como {suma|http://localhost......|campoA|campoB|salida}
	
	//GESTION DEL JUEZ
	if (elemDestino.type=="checkbox"){
		//alert("el juez son checkboxes");
		//recuperamos todos los checkboxes del mismo grupo y sacamos el estilo del ultimo para obtener el estilo del nuevo y de la label
		var checks=document.getElementsByName(elemDestino.name);
		var ultimoCheck=checks[checks.length-1];
		//creamos una nueva label que diga el nombre de la operacion
		var nuevoLabel=document.createElement("font");
		nuevoLabel.setAttribute("color","green");
		nuevoLabel.setAttribute("id","autolabel"+labelOp);
		var italica=document.createElement("I");
		var contenido=document.createTextNode(labelOp);
		italica.appendChild(contenido);
		nuevoLabel.appendChild(italica);
		//nuevoLabel.setAttribute("style","position:absolute; left:"+ultimoCheck.style.left+";top:"+ultimoCheck.style.top+";" );		
		nuevoLabel.style.cssText="position:absolute; left:"+ultimoCheck.style.left+";top:"+ultimoCheck.style.top+";";
		//nuevoLabel.name="autolabel"+operacion;
		//creamos el nuevo radiobutton
		var nuevoCheck = null;
		if (usandoIE()==false){
			nuevoCheck=document.createElement("input");
			nuevoCheck.type="checkbox";
			nuevoCheck.id=labelOp;
			nuevoCheck.name=elemDestino.name;
			nuevoCheck.value=cad;
			nuevoCheck.style.cssText="position:absolute; left:"+ultimoCheck.style.left+";top:"+ultimoCheck.style.top+";";		
		}else{
			nuevoCheck=document.createElement("<input type='checkbox' name='"+elemDestino.name+"' id='"+elemDestino.id+"' value='"+cad+"' style=''/>");
			nuevoCheck.style.cssText="position:absolute; left:"+ultimoCheck.style.left+";top:"+ultimoCheck.style.top+";";	
		}
		
		if (direccion=="horizontal") {
			nuevoLabel.style.left=parseInt(ultimoCheck.style.left)+50;
			nuevoCheck.style.left=parseInt(nuevoLabel.style.left)+80;
		}else{
			nuevoLabel.style.top=parseInt(ultimoCheck.style.top)+50;
			nuevoCheck.style.left=parseInt(nuevoLabel.style.left)+80;
			nuevoCheck.style.top=parseInt(nuevoLabel.style.top);
		}
		
		//a�adimos los  nuevos nodos (la label y el checkbox) como hijos del padre de los chechboxes
		var nodoPadre=elemDestino.parentNode;
		nodoPadre.appendChild(nuevoLabel);
		nodoPadre.appendChild(nuevoCheck);
		
		
	}else if (elemDestino.type=="radio"){
		//alert("el juez son radiobuttons");
		//recuperamos todos los radiobuttons del mismo grupo y sacamos el estilo del ultimo para obtener el estilo del nuevo y de la label
		var radios=document.getElementsByName(elemDestino.name);
		var ultimoRadio=radios[radios.length-1];
		//creamos una nueva label que diga el nombre de la operacion
		var nuevoLabel=document.createElement("font");
		nuevoLabel.setAttribute("color","green");
		nuevoLabel.setAttribute("id","autolabel"+labelOp);
		var italica=document.createElement("I");
		var contenido=document.createTextNode(labelOp);
		italica.appendChild(contenido);
		nuevoLabel.appendChild(italica);
		//nuevoLabel.setAttribute("style","position:absolute; left:"+ultimoRadio.style.left+";top:"+ultimoRadio.style.top+";" );		
		nuevoLabel.style.cssText="position:absolute; left:"+ultimoRadio.style.left+";top:"+ultimoRadio.style.top+";";
		
		//creamos el nuevo radiobutton
		var nuevoRadio = null;
		if (usandoIE()==false){
			nuevoRadio=document.createElement("input");
			nuevoRadio.type="radio";
			nuevoRadio.id=labelOp;
			nuevoRadio.name=elemDestino.name;
			nuevoRadio.value=cad;
			nuevoRadio.style.cssText="position:absolute; left:"+ultimoRadio.style.left+";top:"+ultimoRadio.style.top+";";		
		}else{
			nuevoRadio=document.createElement("<input type='radio' name='"+elemDestino.name+"' id='"+elemDestino.id+"' value='"+cad+"' style=''/>");
			nuevoRadio.style.cssText="position:absolute; left:"+ultimoRadio.style.left+";top:"+ultimoRadio.style.top+";";	
		}
		
		if (direccion=="horizontal") {
			nuevoLabel.style.left=parseInt(ultimoRadio.style.left)+50;
			nuevoRadio.style.left=parseInt(nuevoLabel.style.left)+80;
		}else{
			nuevoLabel.style.top=parseInt(ultimoRadio.style.top)+50;
			nuevoRadio.style.left=parseInt(nuevoLabel.style.left)+80;
			nuevoRadio.style.top=parseInt(nuevoLabel.style.top);
		}
		
		//a�adimos los  nuevos nodos (la label y el radiobutton) como hijos del padre de los radiobuttons
		var nodoPadre=elemDestino.parentNode;
		nodoPadre.appendChild(nuevoLabel);
		nodoPadre.appendChild(nuevoRadio);
		
	}else if (elemDestino.type=="select-one"){
		//alert("el juez es un combo");
		if (compruebaNombreOperacionRepetido(elemDestino,labelOp)==true) return false;
		var newOpt = new Option(labelOp,cad);
		var selLength = elemDestino.length;
		elemDestino.options[selLength] = newOpt;
		
	}else{
		alert("El elemento HTML al que a�adir una operacion debe ser un select, un grupo de radiobuttons o un grupo de checkbuttons");
	}
	
	
	  
	
}

/**
* Funci�n que comprueba que en el combo que se le pasa como par�metro,
* no se encuentre una opci�n cuya label sea el segundo argumento.
**/
function compruebaNombreOperacionRepetido(elemDestino,labelOp){
	for (var i=0;i<elemDestino.options.length;i++){
		if (labelOp==elemDestino.options[i].text){
			//alert(elemDestino.options[i].text);
			alert("No se insert� la operaci�n, ya existe una con el mismo nombre en el combo destino.");
			return true;
		}
	}
	return false;
}


/**
* Funcion que remueve una operacion a ejecutar de un elemento "juez", que decide que operacion se ejecuta
*/
function removeOperationWS(paginaDestino,idElemDestino,idlabeloperacion){
	var elemDestino=null; //el elemento que indicar� las distintas operaciones a ejecutar.
	var otraPagina=false;
	
	var operacion=recogeValorCteOArgumento(idlabeloperacion);
	if (operacion=="") {
		alert("No se especific� la operaci�n a eliminar" ); return false;
	}
	
	//Obtenemos los elementos elemDestino y disparador, que se encuentran en paginaDestino.
	if (paginaDestino=='this'){
		elemDestino=document.getElementById(idElemDestino);
	}else{
		elemDestino=document.getElementById(idElemDestino);	
		ocultaCapasCpC();
		muestraCapa("cpc"+paginaDestino);
	}	
	//
	
	//GESTION DEL JUEZ
	var ok=false;
	if (elemDestino.type=="checkbox"){
		//alert("el juez son checkboxes");
		var padre=elemDestino.parentNode;
		var checks=document.getElementsByName(elemDestino.name);
		for (var i=0;i<checks.length;i++){
			//var er="^"+operacion;
			if (checks[i].id==operacion){
				//alert("checkbox encontrado");
				ok=true;
				checks[i].parentNode.removeChild(checks[i]);
			}
		}
		
	}else if (elemDestino.type=="radio"){
		//alert("el juez son radiobuttons");
		var padre=elemDestino.parentNode;
		var radios=document.getElementsByName(elemDestino.name);
		for (var i=0;i<radios.length;i++){
			//var er="^"+operacion;
			if (radios[i].id==operacion){
				//alert("radio encontrado");
				ok=true;
				radios[i].parentNode.removeChild(radios[i]);
			}
		}
		//borramos la label que lo acompa�a (si existe)
		var labelRadio=document.getElementById("autolabel"+operacion);
		if (labelRadio!=null) {
			labelRadio.parentNode.removeChild(labelRadio);
		}
		
	}else if (elemDestino.type=="select-one"){
		
		var selLength = elemDestino.length;
		for(var i=0;i<selLength;i++){
			var opcion=elemDestino.options[i];
			//var er="^"+operacion;
			if (opcion.text==operacion){
				ok=true;
				elemDestino.options[i]=null;
			}
		}
		
		
	}else{
		alert("El elemento HTML al que quitar una operacion debe ser un select, un grupo de radiobuttons o un grupo de checkbuttons");
	}
	
	if (ok==false) {
			alert("No se encontr� una operaci�n con ese nombre para eliminar");
	}else{
			alert("Operaci�n eliminada");
	}

	if (otraPagina==true) {
		// alert("jur jur");
		windowRes.focus();
	}
	  
	
}

function getElementsByName_IE(tag, name) {
     
     var elems = document.getElementsByTagName(tag);
    var res = [];
    for(var i=0;i<elems.length;i++){
        att = elems[i].getAttribute('name');
        if(att == name) {
            res.push(elems[i]);
        }
    }
    return res;
}

/*funcion que oculta todos los divs cuyo id empieze por "cpc"*/
function ocultaCapasCpC(){
	var capas=null;
	if (usandoIE()){
		capas=getElementsByName_IE("div","capa_cpc");
	}else{
		capas=document.getElementsByName("capa_cpc");
	}
		//alert("num capas="+capas.length);
		for(var i=0;i<capas.length;i++) {
			
				capas[i].style.display="none";
			
		}
	
}

function muestraCapa(id){
	ocultaCapasCpC();
	var capa=document.getElementById(id);
	capa.style.display="block";
	
			
}


function trim(cadena) {
	for(i=0; i<cadena.length; ) {
		if(cadena.charAt(i)==" ")
			cadena=cadena.substring(i+1, cadena.length);
		else
			break;
	}

	for(i=cadena.length-1; i>=0; i=cadena.length-1) {
		if(cadena.charAt(i)==" ")
			cadena=cadena.substring(0,i);
		else
			break;
	}
	
	return cadena;
}

function obtenerPermisosFirefox(){
	if (window.XMLHttpRequest && !navigator.appName.match("Internet Explorer")) {// Si es Mozilla, Safari etc
		netscape.security.PrivilegeManager.enablePrivilege("UniversalBrowserRead");	
	} 
	

}

function usandoIE(){
	if (navigator.appName.match("Internet Explorer")==null){
		return false;
	}else{
		return true;
	}
	
}

function usandoFirefox3(){
	if (navigator.userAgent.indexOf('Firefox/3.')>-1){
		return true;
	}else{
		return false;
	}
}


// document.getElementById abreviado
function $(x) { 
	return document.getElementById(x); 
}



 
 
 